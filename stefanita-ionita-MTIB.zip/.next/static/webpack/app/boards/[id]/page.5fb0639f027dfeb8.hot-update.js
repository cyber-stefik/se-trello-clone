"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/boards/[id]/page",{

/***/ "(app-pages-browser)/./app/actions.ts":
/*!************************!*\
  !*** ./app/actions.ts ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addOrUpdateCard: function() { return /* binding */ addOrUpdateCard; },
/* harmony export */   createBoardItem: function() { return /* binding */ createBoardItem; },
/* harmony export */   createCard: function() { return /* binding */ createCard; },
/* harmony export */   findBoardById: function() { return /* binding */ findBoardById; },
/* harmony export */   findListByName: function() { return /* binding */ findListByName; },
/* harmony export */   getBoardItem: function() { return /* binding */ getBoardItem; },
/* harmony export */   getBoardItems: function() { return /* binding */ getBoardItems; },
/* harmony export */   updateBoard: function() { return /* binding */ updateBoard; },
/* harmony export */   updateBoardList: function() { return /* binding */ updateBoardList; },
/* harmony export */   updateBoardName: function() { return /* binding */ updateBoardName; }
/* harmony export */ });
/* harmony import */ var next_dist_client_app_call_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/client/app-call-server */ "(app-pages-browser)/./node_modules/next/dist/client/app-call-server.js");
/* harmony import */ var next_dist_client_app_call_server__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_app_call_server__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! private-next-rsc-action-client-wrapper */ "(app-pages-browser)/./node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js");



function __build_action__(action, args) {
  return (0,next_dist_client_app_call_server__WEBPACK_IMPORTED_MODULE_0__.callServer)(action.$$id, args)
}

/* __next_internal_action_entry_do_not_use__ {"05053609594209d6ee781614e6c84a472ea5af00":"updateBoardList","29763a4ea5dd53fdcc89c67faae972c957a81293":"getBoardItem","47f83177ef4433b1014a3e985210918967c511a2":"addOrUpdateCard","484ad3bc53e500380c533f27400a82c048820b56":"findBoardById","6d7b28ae8f4b6603766973131a94c88b98e0e035":"createBoardItem","7527440439ad8ed92a520145d2fab590d4a35033":"updateBoard","9d9c59bf21cd1484f4ff251413a4f462bed4943a":"findListByName","ea192448c23430d488d83f4673b4bf6ff41aafb1":"getBoardItems","effe33b21bcb8a16d8e730b55ed264897d46ce77":"createCard","fac6f7a663b7076a0c7b516530e822452bdcb990":"updateBoardName"} */ var addOrUpdateCard = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__.createServerReference)("47f83177ef4433b1014a3e985210918967c511a2");

var getBoardItems = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__.createServerReference)("ea192448c23430d488d83f4673b4bf6ff41aafb1");
var getBoardItem = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__.createServerReference)("29763a4ea5dd53fdcc89c67faae972c957a81293");
var updateBoard = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__.createServerReference)("7527440439ad8ed92a520145d2fab590d4a35033");
var updateBoardList = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__.createServerReference)("05053609594209d6ee781614e6c84a472ea5af00");
var createCard = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__.createServerReference)("effe33b21bcb8a16d8e730b55ed264897d46ce77");
var createBoardItem = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__.createServerReference)("6d7b28ae8f4b6603766973131a94c88b98e0e035");
var findBoardById = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__.createServerReference)("484ad3bc53e500380c533f27400a82c048820b56");
var updateBoardName = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__.createServerReference)("fac6f7a663b7076a0c7b516530e822452bdcb990");
var findListByName = (0,private_next_rsc_action_client_wrapper__WEBPACK_IMPORTED_MODULE_1__.createServerReference)("9d9c59bf21cd1484f4ff251413a4f462bed4943a");



;
    // Wrapped in an IIFE to avoid polluting the global scope
    ;
    (function () {
        var _a, _b;
        // Legacy CSS implementations will `eval` browser code in a Node.js context
        // to extract CSS. For backwards compatibility, we need to check we're in a
        // browser context before continuing.
        if (typeof self !== 'undefined' &&
            // AMP / No-JS mode does not inject these helpers:
            '$RefreshHelpers$' in self) {
            // @ts-ignore __webpack_module__ is global
            var currentExports = module.exports;
            // @ts-ignore __webpack_module__ is global
            var prevSignature = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevSignature) !== null && _b !== void 0 ? _b : null;
            // This cannot happen in MainTemplate because the exports mismatch between
            // templating and execution.
            self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
            // A module can be accepted automatically based on its exports, e.g. when
            // it is a Refresh Boundary.
            if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
                // Save the previous exports signature on update so we can compare the boundary
                // signatures. We avoid saving exports themselves since it causes memory leaks (https://github.com/vercel/next.js/pull/53797)
                module.hot.dispose(function (data) {
                    data.prevSignature =
                        self.$RefreshHelpers$.getRefreshBoundarySignature(currentExports);
                });
                // Unconditionally accept an update to this module, we'll check if it's
                // still a Refresh Boundary later.
                // @ts-ignore importMeta is replaced in the loader
                module.hot.accept();
                // This field is set when the previous version of this module was a
                // Refresh Boundary, letting us know we need to check for invalidation or
                // enqueue an update.
                if (prevSignature !== null) {
                    // A boundary can become ineligible if its exports are incompatible
                    // with the previous exports.
                    //
                    // For example, if you add/remove/change exports, we'll want to
                    // re-execute the importing modules, and force those components to
                    // re-render. Similarly, if you convert a class component to a
                    // function, we want to invalidate the boundary.
                    if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevSignature, self.$RefreshHelpers$.getRefreshBoundarySignature(currentExports))) {
                        module.hot.invalidate();
                    }
                    else {
                        self.$RefreshHelpers$.scheduleUpdate();
                    }
                }
            }
            else {
                // Since we just executed the code for the module, it's possible that the
                // new exports made it ineligible for being a boundary.
                // We only care about the case when we were _previously_ a boundary,
                // because we already accepted this update (accidental side effect).
                var isNoLongerABoundary = prevSignature !== null;
                if (isNoLongerABoundary) {
                    module.hot.invalidate();
                }
            }
        }
    })();


/***/ })

});